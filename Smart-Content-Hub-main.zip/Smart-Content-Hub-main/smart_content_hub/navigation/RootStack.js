import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AppDrawer from './AppDrawer';
import TopicDetailScreen from '../screens/TopicDetailScreen';

const Stack = createNativeStackNavigator();
export default function RootStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="MainApp" component={AppDrawer} options={{ headerShown: false }} />
      <Stack.Screen name="TopicDetail" component={TopicDetailScreen} options={{ title: 'รายละเอียดบทเรียน', headerStyle: { backgroundColor: '#152B49' }, headerTintColor: '#fff' }} />
    </Stack.Navigator>
  );
}
