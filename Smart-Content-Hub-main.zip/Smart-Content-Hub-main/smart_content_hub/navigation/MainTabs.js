import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from '../screens/HomeScreen';
import TeamworkScreen from '../screens/TeamworkScreen';
import RNKnowledgeScreen from '../screens/RNKnowledgeScreen';
import ExploreScreen from '../screens/ExploreScreen';

const Tab = createBottomTabNavigator();
const icons = { Home: 'home-outline', Teamwork: 'people-outline', Knowledge: 'book-outline', Explore: 'compass-outline' };
export default function MainTabs() {
  return (
    <Tab.Navigator screenOptions={({ route }) => ({ headerStyle: { backgroundColor: '#152B49' }, headerTintColor: '#fff', tabBarActiveTintColor: '#1769E0', tabBarInactiveTintColor: '#78869B', tabBarStyle: { height: 62, paddingBottom: 7, paddingTop: 5 }, tabBarIcon: ({ color, size }) => <Ionicons name={icons[route.name]} color={color} size={size} /> })}>
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: 'หน้าหลัก' }} />
      <Tab.Screen name="Teamwork" component={TeamworkScreen} options={{ title: 'ทีมงาน' }} />
      <Tab.Screen name="Knowledge" component={RNKnowledgeScreen} options={{ title: 'คลังความรู้' }} />
      <Tab.Screen name="Explore" component={ExploreScreen} options={{ title: 'สำรวจ' }} />
    </Tab.Navigator>
  );
}
