import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import MainTabs from './MainTabs';
import HowToScreen from '../screens/HowToScreen';
import AboutProjectScreen from '../screens/AboutProjectScreen';
import { Ionicons } from '@expo/vector-icons';

const Drawer = createDrawerNavigator();
export default function AppDrawer() {
  return (
    <Drawer.Navigator screenOptions={{ headerStyle: { backgroundColor: '#152B49' }, headerTintColor: '#fff', drawerActiveTintColor: '#1769E0', drawerLabelStyle: { fontWeight: '600' } }}>
      <Drawer.Screen name="หน้าหลัก" component={MainTabs} options={{ headerShown: false, drawerIcon: ({ color, size }) => <Ionicons name="apps-outline" color={color} size={size} /> }} />
      <Drawer.Screen name="วิธีใช้งาน" component={HowToScreen} options={{ drawerIcon: ({ color, size }) => <Ionicons name="help-circle-outline" color={color} size={size} /> }} />
      <Drawer.Screen name="เกี่ยวกับโครงการ" component={AboutProjectScreen} options={{ drawerIcon: ({ color, size }) => <Ionicons name="information-circle-outline" color={color} size={size} /> }} />
    </Drawer.Navigator>
  );
}
