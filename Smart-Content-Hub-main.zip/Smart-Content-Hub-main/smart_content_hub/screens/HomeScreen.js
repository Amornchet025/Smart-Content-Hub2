import React from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import { topics } from '../data/topics';

export default function HomeScreen({ navigation }) {
  const openTopic = (topic) => navigation.getParent()?.getParent()?.navigate('TopicDetail', { topic }) || navigation.navigate('TopicDetail', { topic });
  return (
    <ScrollView style={s.page} contentContainerStyle={s.content}>
      <View style={s.hero}><Text style={s.kicker}>SMART CONTENT HUB</Text><Text style={s.heroTitle}>เรียนรู้ได้ทุกที่{ '\n' }ในที่เดียว</Text><Text style={s.heroSub}>รวมบทเรียนและแหล่งความรู้สำหรับการพัฒนาแอป</Text></View>
      <Text style={s.heading}>เมนูลัด</Text>
      <View style={s.grid}>
        {[['👥','ทีมงาน','Teamwork'],['📚','คลังความรู้','Knowledge'],['🧭','สำรวจ','Explore'],['💡','วิธีใช้งาน','HowTo']].map(([emoji,label,screen]) => <Pressable key={label} style={s.quick} onPress={() => screen === 'HowTo' ? navigation.getParent()?.navigate('วิธีใช้งาน') : navigation.navigate(screen)}><Text style={s.emoji}>{emoji}</Text><Text style={s.quickText}>{label}</Text></Pressable>)}
      </View>
      <Text style={s.heading}>บทเรียนแนะนำ</Text>
      {topics.slice(0, 3).map(topic => <Pressable key={topic.id} style={s.card} onPress={() => openTopic(topic)}><View style={[s.dot,{backgroundColor:topic.color}]}><Text style={s.dotText}>{topic.id.padStart(2,'0')}</Text></View><View style={{flex:1}}><Text style={s.cardTitle}>{topic.title}</Text><Text style={s.muted}>{topic.category} · แตะเพื่ออ่านรายละเอียด</Text></View><Text style={s.arrow}>›</Text></Pressable>)}
    </ScrollView>
  );
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#F5F8FC'},content:{padding:18,paddingBottom:28},hero:{backgroundColor:'#152B49',padding:22,borderRadius:18,marginBottom:22},kicker:{color:'#FFB21A',fontSize:12,fontWeight:'800',letterSpacing:1},heroTitle:{color:'#fff',fontSize:29,fontWeight:'800',marginTop:10},heroSub:{color:'#D9E5F6',marginTop:8,lineHeight:21},heading:{fontSize:18,fontWeight:'800',color:'#1C3150',marginBottom:12,marginTop:2},grid:{flexDirection:'row',flexWrap:'wrap',gap:10,marginBottom:22},quick:{width:'48%',backgroundColor:'#fff',padding:15,borderRadius:14,borderWidth:1,borderColor:'#E2EAF4'},emoji:{fontSize:24},quickText:{fontWeight:'700',color:'#263B59',marginTop:8},card:{backgroundColor:'#fff',padding:14,borderRadius:14,marginBottom:10,flexDirection:'row',alignItems:'center',gap:12,borderWidth:1,borderColor:'#E5ECF5'},dot:{width:44,height:44,borderRadius:12,alignItems:'center',justifyContent:'center'},dotText:{fontWeight:'800',color:'#1B365B'},cardTitle:{fontSize:15,fontWeight:'700',color:'#1C3150'},muted:{fontSize:12,color:'#7A8AA1',marginTop:5},arrow:{fontSize:27,color:'#7A8AA1'}});
