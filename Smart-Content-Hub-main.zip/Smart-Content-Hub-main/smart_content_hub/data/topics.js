export const topics = [
  { id: '1', title: 'รู้จัก React Native', category: 'พื้นฐาน', color: '#E7F0FF', description: 'React Native เป็นเฟรมเวิร์กสำหรับสร้างแอปพลิเคชันมือถือด้วย JavaScript และ React โดยสามารถพัฒนาแอปสำหรับหลายแพลตฟอร์มจากโค้ดชุดเดียวได้', points: ['แนวคิดของ React Native', 'การสร้าง Component', 'การแสดงผลบนมือถือ'] },
  { id: '2', title: 'การจัดวางหน้าจอด้วย Flexbox', category: 'การออกแบบ UI', color: '#E2F7EF', description: 'Flexbox ช่วยจัดตำแหน่งและกระจายพื้นที่ขององค์ประกอบภายในหน้าจอให้เหมาะกับขนาดอุปกรณ์', points: ['flexDirection', 'justifyContent', 'alignItems'] },
  { id: '3', title: 'การเปลี่ยนหน้าด้วย Navigation', category: 'การพัฒนาแอป', color: '#F0E9FF', description: 'React Navigation ช่วยจัดการการเปลี่ยนหน้า เช่น Stack, Drawer และ Bottom Tabs เพื่อให้ผู้ใช้เข้าถึงส่วนต่าง ๆ ของแอปได้สะดวก', points: ['Stack Navigator', 'Drawer Navigator', 'Bottom Tab Navigator'] },
  { id: '4', title: 'การรับส่งข้อมูล JSON', category: 'ข้อมูล', color: '#FFF0DB', description: 'JSON เป็นรูปแบบข้อมูลที่นิยมใช้แลกเปลี่ยนข้อมูลระหว่างแอปกับบริการภายนอก โดยสามารถอ่านข้อมูลผ่าน fetch ได้', points: ['โครงสร้าง JSON', 'การเรียก fetch()', 'การจัดการ Loading และ Error'] },
  { id: '5', title: 'การจัดการ State', category: 'พื้นฐาน', color: '#E5F7FA', description: 'State ใช้เก็บข้อมูลที่เปลี่ยนแปลงระหว่างใช้งาน และทำให้หน้าจออัปเดตตามข้อมูลล่าสุด', points: ['useState', 'การอัปเดตหน้าจอ', 'การส่งข้อมูลระหว่าง Component'] }
];

export const members = [
  { name: 'สมาชิกคนที่ 1', role: 'วิเคราะห์และออกแบบ', tasks: 'วางแผนโครงสร้างแอป ออกแบบหน้าจอ และรวบรวมความต้องการ' },
  { name: 'สมาชิกคนที่ 2', role: 'พัฒนาโปรแกรม', tasks: 'พัฒนา Navigation, หน้าจอหลัก และเชื่อมโยงข้อมูล' },
  { name: 'สมาชิกคนที่ 3', role: 'ทดสอบและจัดทำรายงาน', tasks: 'ทดสอบการทำงาน จัดทำเอกสาร และเตรียมการนำเสนอ' }
];
